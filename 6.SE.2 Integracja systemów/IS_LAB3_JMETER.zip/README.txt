Windows 11
PHP 8.2.12
Java SE 8