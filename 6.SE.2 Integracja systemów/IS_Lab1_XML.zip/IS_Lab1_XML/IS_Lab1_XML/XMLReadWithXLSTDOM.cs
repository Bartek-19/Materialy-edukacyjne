﻿
using System.Xml.XPath;
using System.Xml;

namespace IS_25_05_06
{
    internal class XMLReadWithXLSTDOM
    {
        internal static void Read(string xmlpath)
        {
            XPathDocument document = new XPathDocument(xmlpath);
            XPathNavigator navigator = document.CreateNavigator();
            XmlNamespaceManager manager = new XmlNamespaceManager(navigator.NameTable);
            manager.AddNamespace("x", "http://rejestrymedyczne.ezdrowie.gov.pl/rpl/eksport-danych-v1.0");

            // 1️⃣ Zliczanie produktów o postaci "Krem" i substancji czynnej "Mometasoni furoas"
            XPathExpression query = navigator.Compile("/x:produktyLecznicze/x:produktLeczniczy[@postac='Krem' and @nazwaPowszechnieStosowana='Mometasoni furoas']");
            query.SetContext(manager);
            int count = navigator.Select(query).Count;

            Console.WriteLine("Liczba produktów leczniczych w postaci kremu, których jedyną substancją czynną jest Mometasoni furoas: {0}", count);

            // 2️⃣ Sprawdzanie liczby produktów o tej samej substancji, ale różnych postaciach
            var slownikNazwaPowszechnieStosowana = new Dictionary<string, HashSet<string>>();

            XPathExpression allProductsQuery = navigator.Compile("/x:produktyLecznicze/x:produktLeczniczy");
            allProductsQuery.SetContext(manager);
            XPathNodeIterator products = navigator.Select(allProductsQuery);

            while (products.MoveNext())
            {
                string sc = products.Current.GetAttribute("nazwaPowszechnieStosowana", "");
                string postac = products.Current.GetAttribute("postac", "");

                if (!string.IsNullOrEmpty(sc) && !string.IsNullOrEmpty(postac))
                {
                    if (!slownikNazwaPowszechnieStosowana.ContainsKey(sc))
                    {
                        slownikNazwaPowszechnieStosowana[sc] = new HashSet<string>();
                    }
                    slownikNazwaPowszechnieStosowana[sc].Add(postac);
                }
            }

            count = slownikNazwaPowszechnieStosowana.Count(nps => nps.Value.Count > 1);
            Console.WriteLine("Liczba produktów leczniczych pod tą samą nazwą powszechnie stosowaną o różnych postaciach: {0}", count);
        }

        internal static void Tabletki_i_Kremy(string xmlpath)
        {
            XPathDocument document = new XPathDocument(xmlpath);
            XPathNavigator navigator = document.CreateNavigator();
            XmlNamespaceManager manager = new XmlNamespaceManager(navigator.NameTable);
            manager.AddNamespace("x", "http://rejestrymedyczne.ezdrowie.gov.pl/rpl/eksport-danych-v1.0");

            var mapaTabletek = new Dictionary<string, int>();
            var mapaKremow = new Dictionary<string, int>();

            XPathExpression query = navigator.Compile("/x:produktyLecznicze/x:produktLeczniczy");
            query.SetContext(manager);
            XPathNodeIterator drugs = navigator.Select(query);

            while (drugs.MoveNext())
            {
                string postac = drugs.Current.GetAttribute("postac", "");
                string podmiot = drugs.Current.GetAttribute("podmiotOdpowiedzialny", "");

                if (postac == "Krem")
                {
                    if (mapaKremow.ContainsKey(podmiot))
                        mapaKremow[podmiot]++;
                    else
                        mapaKremow[podmiot] = 1;
                }
                else if (postac.Contains("Tabletki"))
                {
                    if (mapaTabletek.ContainsKey(podmiot))
                        mapaTabletek[podmiot]++;
                    else
                        mapaTabletek[podmiot] = 1;
                }
            }

            // Znajdujemy producentów z największą liczbą produktów
            string maxKremyKey = mapaKremow.OrderByDescending(x => x.Value).FirstOrDefault().Key;
            string maxTabletkiKey = mapaTabletek.OrderByDescending(x => x.Value).FirstOrDefault().Key;

            Console.WriteLine("Najwięcej tabletek produkuje: {0}", maxTabletkiKey);
            Console.WriteLine("Najwięcej kremów produkuje: {0}", maxKremyKey);
        }

        internal static void Kremy(string xmlpath)
        {
            XPathDocument document = new XPathDocument(xmlpath);
            XPathNavigator navigator = document.CreateNavigator();
            XmlNamespaceManager manager = new XmlNamespaceManager(navigator.NameTable);
            manager.AddNamespace("x", "http://rejestrymedyczne.ezdrowie.gov.pl/rpl/eksport-danych-v1.0");

            var mapaKremow = new Dictionary<string, int>();

            // Wyszukiwanie wszystkich produktów w postaci "Krem"
            XPathExpression query = navigator.Compile("/x:produktyLecznicze/x:produktLeczniczy[@postac='Krem']");
            query.SetContext(manager);
            XPathNodeIterator products = navigator.Select(query);

            while (products.MoveNext())
            {
                string podmiot = products.Current.GetAttribute("podmiotOdpowiedzialny", "");

                // Zwiększamy licznik dla danego producenta
                if (mapaKremow.ContainsKey(podmiot))
                    mapaKremow[podmiot]++;
                else
                    mapaKremow[podmiot] = 1;
            }

            // Znalezienie trzech największych producentów kremów
            var top3 = mapaKremow.OrderByDescending(x => x.Value).Take(3).ToList();

            Console.WriteLine("Trzej producenci z największą ilością wyprodukowanych kremów:");
            for (int i = 0; i < top3.Count; i++)
            {
                Console.WriteLine("{0} : {1}", top3[i].Key, top3[i].Value);
            }
        }
    }
}