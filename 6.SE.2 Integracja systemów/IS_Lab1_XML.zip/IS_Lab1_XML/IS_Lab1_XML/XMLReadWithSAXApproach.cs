﻿using System.Xml;

namespace IS_25_05_06
{
    internal class XMLReadWithSAXApproach
    {
        internal static void Read(string filepath)
        {
            // konfiguracja początkowa dla XmlReadera
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreComments = true;
            settings.IgnoreProcessingInstructions = true;
            settings.IgnoreWhitespace = true;
            // odczyt zawartości dokumentu
            XmlReader reader = XmlReader.Create(filepath, settings);
            // zmienne pomocnicze
            int count = 0;
            string postac = "";
            string sc = "";
            reader.MoveToContent();
            var slownikNazwaPowszechnieStosowana = new Dictionary<String, HashSet<string>>();
            // analiza każdego z węzłów dokumentu
            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element && reader.Name == "produktLeczniczy")
                {
                    postac = reader.GetAttribute("postac");
                    sc = reader.GetAttribute("nazwaPowszechnieStosowana");
                    if (postac == "Krem" && sc == "Mometasoni furoas")
                        count++;
                }
                if (slownikNazwaPowszechnieStosowana.ContainsKey(sc))
                {
                    slownikNazwaPowszechnieStosowana[sc].Add(postac);
                }
                else
                {
                    var temp = new HashSet<string>();
                    temp.Add(postac);
                    slownikNazwaPowszechnieStosowana.Add(sc, temp);
                }
            }
            Console.WriteLine("Liczba produktów leczniczych w postaci kremu, których jedyną substancją czynną jest Mometasoni furoas: {0}", count);
            count = 0;
            foreach (var nps in slownikNazwaPowszechnieStosowana)
            {
                if (nps.Value.Count > 1)
                {
                    count++;
                }
            }
            Console.WriteLine("Liczba produktow leczniczych pod ta sama nazwa powszechnie stosowana o roznych postaciach: {0}", count);
        }

        internal static void Tabletki_i_Kremy(string filepath)
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreComments = true;
            settings.IgnoreProcessingInstructions = true;
            settings.IgnoreWhitespace = true;
            // odczyt zawartości dokumentu
            XmlReader reader = XmlReader.Create(filepath, settings);
            // zmienne pomocnicze
            string postac;
            string podmiot;

            var mapaTabletek = new Dictionary<string, int>();
            var mapaKremow = new Dictionary<string, int>();

            reader.MoveToContent();

            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element && reader.Name == "produktLeczniczy")
                {
                    postac = reader.GetAttribute("postac");
                    podmiot = reader.GetAttribute("podmiotOdpowiedzialny");
                    if (postac == "Krem")
                    {
                        if (mapaKremow.ContainsKey(podmiot))
                        {
                            mapaKremow[podmiot]++;
                        }
                        else
                        {
                            mapaKremow.Add(podmiot, 1);
                        }
                    }

                    if (postac.Contains("Tabletki"))
                    {
                        if (mapaTabletek.ContainsKey(podmiot))
                        {
                            mapaTabletek[podmiot]++;
                        }
                        else
                        {
                            mapaTabletek.Add(podmiot, 1);
                        }
                    }
                }
            }

            var maxKremyKey = mapaKremow.ElementAt(0).Key;
            var maxTabletkiKey = mapaTabletek.ElementAt(0).Key;

            for (int i = 1; i < mapaKremow.Count; i++)
                if (mapaKremow[maxKremyKey] < mapaKremow.ElementAt(i).Value)
                    maxKremyKey = mapaKremow.ElementAt(i).Key;

            for (int i = 1; i < mapaTabletek.Count; i++)
                if (mapaTabletek[maxTabletkiKey] < mapaTabletek.ElementAt(i).Value)
                    maxTabletkiKey = mapaTabletek.ElementAt(i).Key;

            Console.WriteLine("Najwięcej tabletek produkuje: {0}", maxTabletkiKey);
            Console.WriteLine("Najwięcej kremow produkuje: {0}", maxKremyKey);
        }

        internal static void Kremy(string filepath)
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreComments = true;
            settings.IgnoreProcessingInstructions = true;
            settings.IgnoreWhitespace = true;
            // odczyt zawartości dokumentu
            XmlReader reader = XmlReader.Create(filepath, settings);
            // zmienne pomocnicze
            string postac = "";
            string podmiot = "";
            var mapaKremow = new Dictionary<string, int>();
            reader.MoveToContent();

            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element && reader.Name == "produktLeczniczy")
                {
                    postac = reader.GetAttribute("postac");
                    podmiot = reader.GetAttribute("podmiotOdpowiedzialny");
                }

                if (postac == "Krem")
                {
                    if (mapaKremow.ContainsKey(podmiot))
                        mapaKremow[podmiot] ++;
                    else
                        mapaKremow.Add(podmiot, 1);
                }
            }

            var top3 = mapaKremow.OrderByDescending(x => x.Value).Take(3).ToList();

            Console.WriteLine("Top 3 producenci kremów:");
            for (int i = 0; i < top3.Count; i++)
            {
                Console.WriteLine("{0} : {1}", top3[i].Key, top3[i].Value);
            }
        }
    }
}