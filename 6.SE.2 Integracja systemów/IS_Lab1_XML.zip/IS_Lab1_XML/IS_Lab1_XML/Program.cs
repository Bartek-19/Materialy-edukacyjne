﻿using System;
using System.IO;

//Podajemy system operacyjny i wersję używanego .NETa
//Przesyłamy pliki z folderu Debug/net8.0

//Console.WriteLine("{0}, {1}, {2}", var0, var1, var2);

namespace IS_25_05_06
{
    class Program
    {
        static void Main(string[] args)
        {
            string xmlpath = Path.Combine("Assets", "data.xml");
            
            // odczyt danych z wykorzystaniem DOM
            Console.WriteLine("XML loaded by DOM Approach");
            XMLReadWithDOMApproach.Read(xmlpath);
            XMLReadWithDOMApproach.Tabletki_i_Kremy(xmlpath);
            XMLReadWithDOMApproach.Kremy(xmlpath);
            Console.WriteLine(" ");
            
            // odczyt danych z wykorzystaniem SAX
            Console.WriteLine("XML loaded by SAX Approach");
            XMLReadWithSAXApproach.Read(xmlpath);
            XMLReadWithSAXApproach.Tabletki_i_Kremy(xmlpath);
            XMLReadWithSAXApproach.Kremy(xmlpath);
            Console.WriteLine(" ");
            
            // odczyt danych z wykorzystaniem XPath i DOM
            Console.WriteLine("XML loaded with XPath");
            XMLReadWithXLSTDOM.Read(xmlpath);
            XMLReadWithXLSTDOM.Tabletki_i_Kremy(xmlpath);
            XMLReadWithXLSTDOM.Kremy(xmlpath);
            
            Console.ReadLine();
        }
    }
}