.NET 8.0
Windows 11