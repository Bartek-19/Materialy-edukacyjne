Windows 11
PHP 8.2.12
JDK 21
Xampp 3.3.0