package com.lg;

public class Main {
//OS, PHP, JDK, XAMPP, PROJEKT PHP, JAVA, SSy i exporty
    public static void main(String[] args) {
        Logic logic = new Logic("http://localhost/IS_LAB6_REST/Cities/read/11");
        //Logic logic = new Logic("http://localhost/IS_LAB6_REST/Cities/read");
        Presentation.printData(logic.getRecieveddata());
    }
}