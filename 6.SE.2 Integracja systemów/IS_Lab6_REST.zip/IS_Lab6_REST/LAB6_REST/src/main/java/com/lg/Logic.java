package com.lg;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.stream.Collectors;

public class Logic {
    private URL url;
    private InputStream is;
    private String source;
    private JSONObject json;
    private JSONArray recieveddata;

    public Logic(String urlAddress) {
        try {
            this.url = new URL(urlAddress);
            System.out.println("Wysyłanie zapytania...");

            this.is = url.openStream();
            System.out.println("Pobieranie odpowiedzi...");

            this.source = new BufferedReader(new InputStreamReader(is)).lines().collect(Collectors.joining("\n"));
            System.out.println("Przetwarzanie danych...");

            json = new JSONObject(source);
            recieveddata = (JSONArray) json.get("cities");

        } catch (Exception e) {
            System.err.println("Wystąpił nieoczekiwany błąd!!!");
            e.printStackTrace(System.err);
        }
    }

    public JSONArray getRecieveddata() {
        return recieveddata;
    }
}
