package com.lg;

import org.json.JSONArray;

public class Presentation {
    public static void printData(JSONArray data) {
        if(data.length() == 1) {
            System.out.println("City ID:     " + data.getJSONObject(0).get("ID"));
            System.out.println("City name:   " + data.getJSONObject(0).get("Name"));
            System.out.println("Country code:" + data.getJSONObject(0).get("CountryCode"));
            System.out.println("District:    " + data.getJSONObject(0).get("District"));
            System.out.println("Population:  " + data.getJSONObject(0).get("Population"));
        } else {
            for(int i=0; i< data.length(); i++) {
                System.out.print("City ID: " + data.getJSONObject(i).get("ID") + " | ");
                System.out.print("City name: " + data.getJSONObject(i).get("Name") + " | ");
                System.out.print("Country code: " + data.getJSONObject(i).get("CountryCode") + " | ");
                System.out.print("District: " + data.getJSONObject(i).get("District") + " | ");
                System.out.print("Population: " + data.getJSONObject(i).get("Population") + "\n");
            }
        }
    }
}
