# -*- coding: utf-8 -*- 
""" 
deserialize json 
""" 
import json 
class DeserializeJson: 
# konstruktor 
    def __init__(self, filename): 
        print("let's deserialize something") 
        tempdata = open(filename, encoding="utf8") 
        self.data = json.load(tempdata) 
        # przykładowe statystyki 
    
    def somestats(self): 
        example_stat = 0 
        urzedy_w_wojewodztwach = {}
        for dep in self.data:
            woj = dep['Województwo'].replace(" ", "")
            if woj not in urzedy_w_wojewodztwach:
                urzedy_w_wojewodztwach[woj] = []
            urzedy_w_wojewodztwach[woj].append(dep['typ_JST'])
        
        for wojewodztwo in urzedy_w_wojewodztwach:
            print("> ", wojewodztwo, ", ", len(urzedy_w_wojewodztwach[wojewodztwo]), ":")
            typy_urzedow = set(urzedy_w_wojewodztwach[wojewodztwo])
            for t in typy_urzedow:
                print("> ", t, ": ", urzedy_w_wojewodztwach[wojewodztwo].count(t))
            print(" ")

        