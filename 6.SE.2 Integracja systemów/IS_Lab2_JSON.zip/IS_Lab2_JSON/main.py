import yaml
from deserialize_json import DeserializeJson
from serialize_json import SerializeJson
from convert_json_to_yaml import ConvertJsonToYaml 

tempconffile = open('basic_config.yaml', encoding="utf8") 
confdata = yaml.load(tempconffile, Loader=yaml.FullLoader) 
newDeserializator = DeserializeJson('Assets/data.json') 

print("Konwersje z JSON do YAML")

print("Wybierz źródło danych (1-zdeserializowany obiekt JSON, 2-plik JSON):")
wybor = 0
while wybor!=1 and wybor!=2:
    wybor = int(input())

print("Lista operacji:")
print("1. Wyświetlenie informacji o urzędach w województwach")
print("2. Serializacja danych do uproszczonego formatu")
print("3. Konwersja do pliku YAML")
print("Wprowadz numer operacji, którą chcesz wykonac, w kolejnosci, w ktorej maja zostac wykonane")
print("(Wprowadź dowolną liczbę, aby pominąć dany krok):")
operacje = []
for i in range(0, 3):
    temp = int(input())
    operacje.append(temp)

for i in operacje:
    if i == 1:
        newDeserializator.somestats()
    elif i == 2:
        SerializeJson.run(newDeserializator, confdata['paths']['source_folder']+confdata['paths']['json_destination_file']) 
    elif i == 3:
        if wybor == 1:
            ConvertJsonToYaml.run(newDeserializator, confdata['paths']['source_folder']+confdata['paths']['yaml_destination_file']) 
        else:
            ConvertJsonToYaml.run(confdata['paths']['source_folder']+confdata['paths']['json_source_file'], confdata['paths']['source_folder']+confdata['paths']['yaml_destination_file'])
