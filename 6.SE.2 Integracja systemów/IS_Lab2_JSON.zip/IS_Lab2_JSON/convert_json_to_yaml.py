# -*- coding: utf-8 -*- 
""" 
json to yaml converter 
""" 
import yaml 
import json
from deserialize_json import DeserializeJson

class ConvertJsonToYaml: 
    @staticmethod 
    def run(data, destinationfilelocaiton): 
        if(data.__class__ == DeserializeJson):
            print("let's convert something") 
            with open(destinationfilelocaiton, 'w', encoding='utf8') as f: 
                yaml.dump(data, f, allow_unicode=True, sort_keys=False) 
            print("it is done") 
        elif(data.__class__ == str):
            print("let's convert something from the file")
            content = json.load(open(data, encoding="utf8"))
            with open(destinationfilelocaiton, 'w', encoding='utf8') as f: 
                yaml.dump(content, f, allow_unicode=True, sort_keys=False)
            print("it is done") 
        

