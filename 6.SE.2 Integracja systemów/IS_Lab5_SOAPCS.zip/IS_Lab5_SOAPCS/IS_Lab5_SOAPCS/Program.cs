﻿using ServiceReference1;

Console.WriteLine("My First SOAP Client!");
MyFirstSOAPInterfaceClient client = new MyFirstSOAPInterfaceClient();
string text = await client.getHelloWorldAsStringAsync("Karol");
long days = await client.getDaysBetweenDatesAsync("01-02-2024 00:01", "07-03-2024 00:02");
Console.WriteLine(text);
Console.WriteLine(days);
