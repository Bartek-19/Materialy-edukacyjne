package com.lg;

import javax.xml.ws.Endpoint;

public class Main {
    //Wysłać README (Wersja JDK, Wersja .NET, OS), Folder na projekty Java i C#, Folder na SSy i wygenerowaną dokumentację SoapUI
    public static void main(String[] args) {
        Endpoint.publish("http://localhost:7779/ws/first", new MyFirstWS());
    }
}