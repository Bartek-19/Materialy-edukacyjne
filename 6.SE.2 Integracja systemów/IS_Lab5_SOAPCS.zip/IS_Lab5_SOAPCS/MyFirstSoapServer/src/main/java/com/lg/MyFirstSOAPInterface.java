package com.lg;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

//Service Endpoint Interface
@WebService // oznaczenie klasy jako SEO (Service Endpoint Interface)
@SOAPBinding(style = SOAPBinding.Style.RPC)
public interface MyFirstSOAPInterface{
    @WebMethod String getHelloWorldAsString(String name);
    @WebMethod long getDaysBetweenDates(String date1, String date2);
}
