Windows 11
JDK 21
.NET 8.0