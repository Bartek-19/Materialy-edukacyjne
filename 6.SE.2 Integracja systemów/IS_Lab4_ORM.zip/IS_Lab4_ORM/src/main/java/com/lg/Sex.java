package com.lg;

public enum Sex { MALE, FEMALE }
