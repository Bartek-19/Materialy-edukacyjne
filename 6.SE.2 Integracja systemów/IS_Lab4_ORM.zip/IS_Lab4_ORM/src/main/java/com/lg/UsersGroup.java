package com.lg;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
public class UsersGroup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private final Set<User> users = new HashSet<>();

    public UsersGroup() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void addUser(User u) {
        this.users.add(u);
    }
}
