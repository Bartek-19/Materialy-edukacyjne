package com.lg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/*Do wysłania: readme, folder projektu, wideo z działania programu */

public class Main {
    public static void main(String[] args) {
        System.out.println("JPA project");
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("Hibernate_JPA");
        EntityManager em = factory.createEntityManager();

        User u1 = new User("test_1","test_1","Andrzej", "Kowalski", Sex.MALE);
        List<Role> roles = new ArrayList<>();
        roles.add(new Role("Admin"));
        roles.add(new Role("User"));
        roles.add(new Role("Privileged User"));
        roles.add(new Role("Visitor"));
        roles.add(new Role("Inactive user"));
        List<User> users = new ArrayList<>();
        users.add(new User("test_2","test_2","Jan", "Sawa", Sex.MALE));
        users.add(new User("test_3","test_3","Anna", "Malecka", Sex.FEMALE));
        users.add(new User("test_4","test_4","Adam", "Stary", Sex.MALE));
        users.add(new User("test_5","test_5","Kawa", "Saki", Sex.FEMALE));
        users.add(new User("test_6","test_6","Saku", "Ra", Sex.MALE));
//Zrobione do 4.3.1

        em.getTransaction().begin();

        em.persist(u1);

        for(Role r : roles) {
            em.persist(r);
        }

        for(User u : users) {
            em.persist(u);
        }

        User u2 = em.find(User.class, (long)1);
        u2.setPassword("NewPassword");
        em.merge(u2);

        Role r1 = em.find(Role.class, (long)5);
        em.remove(r1);

        //Query query = em.createQuery("SELECT u FROM User u WHERE u.lastName = 'Kowalski'");
        //List<User> kowalscy = query.getResultList();

        Query selectWomen = em.createQuery("SELECT u FROM User u WHERE u.sex = 'FEMALE'");
        List<User> women = selectWomen.getResultList();
        for(User u : women) {
            System.out.println(u.getId()+". "+u.getFirstName()+" "+u.getLastName()+" "+u.getLogin()+" "+u.getPassword());
        }

        User u3 = new User("test_7", "test_7", "Test", "User", Sex.MALE);
        u3.addRole(roles.get(1));
        u3.addRole(roles.get(3));
        em.persist(u3);

        UsersGroup g1 = new UsersGroup();
        g1.addUser(users.get(1));
        g1.addUser(u3);
        em.persist(g1);

        em.getTransaction().commit();
        em.close();
        factory.close();
    }
}