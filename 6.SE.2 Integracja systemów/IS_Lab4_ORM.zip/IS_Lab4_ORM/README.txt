Windows 11
Java 21