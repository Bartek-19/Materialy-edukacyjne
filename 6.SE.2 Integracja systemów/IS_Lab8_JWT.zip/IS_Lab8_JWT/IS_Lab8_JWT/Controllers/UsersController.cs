﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IS_Lab8_JWT.Model;
using IS_Lab8_JWT.Services.Users;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using IS_Lab8_JWT.Entities;

namespace IS_Lab8_JWT.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private IUserService userService;

        public UsersController(IUserService userService)
        {
            this.userService = userService;
        }

        //
        [HttpPost("authenticate")]
        public IActionResult Authenticate(AuthenticationRequest request)
        {
            var response = userService.Authenticate(request);

            if (response == null)
                return BadRequest(new
                {
                    message = "Username or password is incorrect"
                });

            return Ok(response);
        }

        [HttpGet("allUsers")]
        [Authorize(Roles = "admin", AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public IActionResult allUsers() {
            var users = userService.GetUsers();
            return Ok(users);
        }

        [HttpGet("countUsers")]
        [Authorize(Roles = "user", AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public IActionResult countUsers()
        {
            var users = userService.GetUsers().Count();
            return Ok(users);
        }
    }
}
