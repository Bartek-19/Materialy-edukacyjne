﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IS_Lab8_JWT.Model;
using IS_Lab8_JWT.Services.Users;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using IS_Lab8_JWT.Entities;


namespace IS_Lab8_JWT.Controllers
{
    [Route("api")]
    [ApiController]
    public class MagicNumbersController : ControllerBase
    {
        private int[] numbers = { 2, 3, 5, 7, 11, 13};
        private Random rand = new Random();

        [HttpGet("magicnumbers")]
        [Authorize(Roles = "number", AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public IActionResult magicnumbers()
        {
            var number = numbers[ rand.Next(numbers.Length) ];
            return Ok(number);
        }
    }
}
