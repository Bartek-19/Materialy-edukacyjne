﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IS_Lab8_JWT.Entities
{
    public class Role
    {
        public string Role_ { get; set; }
    }
}
