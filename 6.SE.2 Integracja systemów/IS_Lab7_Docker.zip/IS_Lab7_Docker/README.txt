Windows 11
Docker 28.0.4
Docker-Compose v2.34.0
