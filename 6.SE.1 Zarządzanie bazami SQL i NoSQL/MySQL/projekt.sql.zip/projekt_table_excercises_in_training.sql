
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `excercises_in_training`
--
-- Creation: Mar 12, 2025 at 03:45 PM
--

DROP TABLE IF EXISTS `excercises_in_training`;
CREATE TABLE IF NOT EXISTS `excercises_in_training` (
  `excercise_id` int(11) NOT NULL,
  `repetitions` int(11) NOT NULL,
  `sets` int(11) NOT NULL,
  `weight` float NOT NULL,
  `training_plan_id` int(11) NOT NULL,
  `effort_type_id` int(11) NOT NULL,
  PRIMARY KEY (`excercise_id`,`training_plan_id`),
  KEY `fk_excercise_has_training_plan_excercise_idx` (`excercise_id`),
  KEY `fk_excercise_in_training_plan_trainings1_idx` (`training_plan_id`),
  KEY `fk_excercises_in_training_effort_type1_idx` (`effort_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `excercises_in_training`:
--   `excercise_id`
--       `excercise` -> `id`
--   `training_plan_id`
--       `training_day` -> `training_plan_id`
--   `effort_type_id`
--       `effort_type` -> `id`
--
