
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users_training_plans`
--
-- Creation: Mar 12, 2025 at 03:45 PM
--

DROP TABLE IF EXISTS `users_training_plans`;
CREATE TABLE IF NOT EXISTS `users_training_plans` (
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `begin_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`user_id`,`plan_id`),
  KEY `fk_user_has_training_plan_training_plan1_idx` (`plan_id`),
  KEY `fk_user_has_training_plan_user1_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `users_training_plans`:
--   `plan_id`
--       `training_plan` -> `id`
--   `user_id`
--       `user` -> `id`
--
