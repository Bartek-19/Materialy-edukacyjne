
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `excercise_category`
--
-- Creation: Mar 12, 2025 at 03:55 PM
-- Ostatnia aktualizacja: Mar 12, 2025 at 04:00 PM
--

DROP TABLE IF EXISTS `excercise_category`;
CREATE TABLE IF NOT EXISTS `excercise_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categroy_name_UNIQUE` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `excercise_category`:
--

--
-- Dumping data for table `excercise_category`
--

INSERT DELAYED IGNORE INTO `excercise_category` (`id`, `category_name`) VALUES
(2, 'Compound'),
(1, 'Global'),
(3, 'Isolated');
