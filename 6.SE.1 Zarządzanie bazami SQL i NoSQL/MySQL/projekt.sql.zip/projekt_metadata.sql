
--
-- Constraints for dumped tables
--

--
-- Constraints for table `end_survey`
--
ALTER TABLE `end_survey`
  ADD CONSTRAINT `fk_end_survey_users_training_plans1` FOREIGN KEY (`user_id`,`users_training_plan_id`) REFERENCES `users_training_plans` (`user_id`, `plan_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `excercise`
--
ALTER TABLE `excercise`
  ADD CONSTRAINT `fk_excercise_excercise_category1` FOREIGN KEY (`excercise_category_id`) REFERENCES `excercise_category` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `excercises_in_training`
--
ALTER TABLE `excercises_in_training`
  ADD CONSTRAINT `fk_excercise_has_training_plan_excercise` FOREIGN KEY (`excercise_id`) REFERENCES `excercise` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_excercise_in_training_plan_trainings1` FOREIGN KEY (`training_plan_id`) REFERENCES `training_day` (`training_plan_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_excercises_in_training_effort_type1` FOREIGN KEY (`effort_type_id`) REFERENCES `effort_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `excercise_has_movement_pattern`
--
ALTER TABLE `excercise_has_movement_pattern`
  ADD CONSTRAINT `fk_excercise_has_movement_pattern_excercise1` FOREIGN KEY (`excercise_id`) REFERENCES `excercise` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_excercise_has_movement_pattern_movement_pattern1` FOREIGN KEY (`movement_pattern_id`) REFERENCES `movement_pattern` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `excercise_target_muscle_group`
--
ALTER TABLE `excercise_target_muscle_group`
  ADD CONSTRAINT `fk_excercise_has_excercise_target_muscle_group_excercise1` FOREIGN KEY (`excercise_id`) REFERENCES `excercise` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_excercise_has_excercise_target_muscle_group_excercise_targ1` FOREIGN KEY (`target_muscle_group_id`) REFERENCES `target_muscle_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `executed_sets`
--
ALTER TABLE `executed_sets`
  ADD CONSTRAINT `fk_executed_sets_excercise1` FOREIGN KEY (`excercise_id`) REFERENCES `excercise` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_executed_sets_training_day1` FOREIGN KEY (`training_day_id`,`training_plan_id`) REFERENCES `training_day` (`id`, `training_plan_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `training_day`
--
ALTER TABLE `training_day`
  ADD CONSTRAINT `fk_trainings_training_plan1` FOREIGN KEY (`training_plan_id`) REFERENCES `training_plan` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `training_plan`
--
ALTER TABLE `training_plan`
  ADD CONSTRAINT `fk_training_plan_training_method1` FOREIGN KEY (`training_method_id`) REFERENCES `training_method` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `users_training_plans`
--
ALTER TABLE `users_training_plans`
  ADD CONSTRAINT `fk_user_has_training_plan_training_plan1` FOREIGN KEY (`plan_id`) REFERENCES `training_plan` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_has_training_plan_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user_records`
--
ALTER TABLE `user_records`
  ADD CONSTRAINT `fk_user_stats_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user_stats`
--
ALTER TABLE `user_stats`
  ADD CONSTRAINT `fk_user_stats_user2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;


--
-- Metadane
--
USE `phpmyadmin`;

--
-- Metadane dla tabeli effort_type
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli end_survey
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli excercise
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli excercises_in_training
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli excercise_category
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli excercise_has_movement_pattern
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli excercise_target_muscle_group
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli executed_sets
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli movement_pattern
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli target_muscle_group
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli training_day
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli training_method
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli training_plan
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli user
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli users_training_plans
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli user_records
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla tabeli user_stats
--
-- Error reading data for table phpmyadmin.pma__table_uiprefs: #1100 - Tabela &#039;pma__table_uiprefs&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__tracking: #1100 - Tabela &#039;pma__tracking&#039; nie została zablokowana poleceniem LOCK TABLES

--
-- Metadane dla Bazy danych projekt
--
-- Error reading data for table phpmyadmin.pma__relation: #1100 - Tabela &#039;pma__relation&#039; nie została zablokowana poleceniem LOCK TABLES
-- Error reading data for table phpmyadmin.pma__savedsearches: #1100 - Tabela &#039;pma__savedsearches&#039; nie została zablokowana poleceniem LOCK TABLES
