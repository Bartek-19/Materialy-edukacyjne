
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `training_day`
--
-- Creation: Mar 12, 2025 at 03:56 PM
--

DROP TABLE IF EXISTS `training_day`;
CREATE TABLE IF NOT EXISTS `training_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_plan_id` int(11) NOT NULL,
  `week_day` varchar(45) NOT NULL,
  `week` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`,`training_plan_id`),
  KEY `fk_trainings_training_plan1` (`training_plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `training_day`:
--   `training_plan_id`
--       `training_plan` -> `id`
--
