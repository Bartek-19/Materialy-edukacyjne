
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `excercise_target_muscle_group`
--
-- Creation: Mar 12, 2025 at 03:45 PM
--

DROP TABLE IF EXISTS `excercise_target_muscle_group`;
CREATE TABLE IF NOT EXISTS `excercise_target_muscle_group` (
  `excercise_id` int(11) NOT NULL,
  `target_muscle_group_id` int(11) NOT NULL,
  PRIMARY KEY (`excercise_id`,`target_muscle_group_id`),
  KEY `fk_excercise_has_excercise_target_muscle_group_excercise_ta_idx` (`target_muscle_group_id`),
  KEY `fk_excercise_has_excercise_target_muscle_group_excercise1_idx` (`excercise_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `excercise_target_muscle_group`:
--   `excercise_id`
--       `excercise` -> `id`
--   `target_muscle_group_id`
--       `target_muscle_group` -> `id`
--
