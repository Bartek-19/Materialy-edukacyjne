
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `training_plan`
--
-- Creation: Mar 12, 2025 at 03:56 PM
--

DROP TABLE IF EXISTS `training_plan`;
CREATE TABLE IF NOT EXISTS `training_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `training_method_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_training_plan_training_method1_idx` (`training_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `training_plan`:
--   `training_method_id`
--       `training_method` -> `id`
--
