
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `executed_sets`
--
-- Creation: Mar 12, 2025 at 03:55 PM
--

DROP TABLE IF EXISTS `executed_sets`;
CREATE TABLE IF NOT EXISTS `executed_sets` (
  `id` int(11) NOT NULL,
  `excercise_id` int(11) NOT NULL,
  `executed_repetitions` int(11) NOT NULL,
  `wieght_used` float NOT NULL,
  `training_day_id` int(11) NOT NULL,
  `training_plan_id` int(11) NOT NULL,
  PRIMARY KEY (`excercise_id`,`id`,`training_day_id`,`training_plan_id`),
  KEY `fk_executed_sets_excercise1_idx` (`excercise_id`),
  KEY `fk_executed_sets_training_day1_idx` (`training_day_id`,`training_plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `executed_sets`:
--   `excercise_id`
--       `excercise` -> `id`
--   `training_day_id`
--       `training_day` -> `id`
--   `training_plan_id`
--       `training_day` -> `training_plan_id`
--
