
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `user_records`
--
-- Creation: Mar 12, 2025 at 03:45 PM
--

DROP TABLE IF EXISTS `user_records`;
CREATE TABLE IF NOT EXISTS `user_records` (
  `user_id` int(11) NOT NULL,
  `max_squat` float DEFAULT NULL,
  `max_bench` float DEFAULT NULL,
  `max_deadlift` float DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `fk_user_stats_user1_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `user_records`:
--   `user_id`
--       `user` -> `id`
--
