
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `training_method`
--
-- Creation: Mar 12, 2025 at 03:54 PM
--

DROP TABLE IF EXISTS `training_method`;
CREATE TABLE IF NOT EXISTS `training_method` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `duration_of_cycle` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `method_id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `training_method`:
--

--
-- Dumping data for table `training_method`
--

INSERT DELAYED IGNORE INTO `training_method` (`id`, `name`, `duration_of_cycle`) VALUES
(1, '5x5', 4),
(2, '5x30', 1),
(3, 'Texas Method', 3),
(4, 'Condense Conjugate', 4);
