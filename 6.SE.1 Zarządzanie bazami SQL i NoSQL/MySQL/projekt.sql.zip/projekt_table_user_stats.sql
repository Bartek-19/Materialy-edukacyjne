
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `user_stats`
--
-- Creation: Mar 12, 2025 at 03:45 PM
--

DROP TABLE IF EXISTS `user_stats`;
CREATE TABLE IF NOT EXISTS `user_stats` (
  `user_id` int(11) NOT NULL,
  `plans_completed` int(11) NOT NULL,
  `trainings_completed` int(11) NOT NULL,
  `sets_completed` int(11) NOT NULL,
  `total_tonnage` float NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `user_stats`:
--   `user_id`
--       `user` -> `id`
--
