
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `effort_type`
--
-- Creation: Mar 12, 2025 at 03:54 PM
--

DROP TABLE IF EXISTS `effort_type`;
CREATE TABLE IF NOT EXISTS `effort_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `effort_type_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `effort_type_name_UNIQUE` (`effort_type_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `effort_type`:
--
