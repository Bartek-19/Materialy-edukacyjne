
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `excercise_has_movement_pattern`
--
-- Creation: Mar 12, 2025 at 03:45 PM
--

DROP TABLE IF EXISTS `excercise_has_movement_pattern`;
CREATE TABLE IF NOT EXISTS `excercise_has_movement_pattern` (
  `excercise_id` int(11) NOT NULL,
  `movement_pattern_id` int(11) NOT NULL,
  PRIMARY KEY (`excercise_id`,`movement_pattern_id`),
  KEY `fk_excercise_has_movement_pattern_movement_pattern1_idx` (`movement_pattern_id`),
  KEY `fk_excercise_has_movement_pattern_excercise1_idx` (`excercise_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `excercise_has_movement_pattern`:
--   `excercise_id`
--       `excercise` -> `id`
--   `movement_pattern_id`
--       `movement_pattern` -> `id`
--
