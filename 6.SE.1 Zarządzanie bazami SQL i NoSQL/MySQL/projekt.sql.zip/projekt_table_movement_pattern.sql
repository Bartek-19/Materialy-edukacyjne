
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `movement_pattern`
--
-- Creation: Mar 12, 2025 at 03:56 PM
-- Ostatnia aktualizacja: Mar 12, 2025 at 04:13 PM
--

DROP TABLE IF EXISTS `movement_pattern`;
CREATE TABLE IF NOT EXISTS `movement_pattern` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `movement_pattern`:
--

--
-- Dumping data for table `movement_pattern`
--

INSERT DELAYED IGNORE INTO `movement_pattern` (`id`, `name`) VALUES
(11, 'Anti-Extension'),
(10, 'Anti-Flexion'),
(12, 'Anti-Lateral Flexion'),
(9, 'Anti-Rotation'),
(2, 'Hip Dominant'),
(1, 'Hip Hinge'),
(7, 'Horizontal Pull'),
(6, 'Horizontal Push'),
(3, 'Knee Dominant'),
(8, 'Rotational and Diagonal'),
(5, 'Vertical Pull'),
(4, 'Vertical Push');
