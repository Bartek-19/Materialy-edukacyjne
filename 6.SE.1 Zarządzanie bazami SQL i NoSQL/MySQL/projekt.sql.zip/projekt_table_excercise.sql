
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `excercise`
--
-- Creation: Mar 12, 2025 at 03:56 PM
--

DROP TABLE IF EXISTS `excercise`;
CREATE TABLE IF NOT EXISTS `excercise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `excercise_category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_excercise_excercise_category1_idx` (`excercise_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `excercise`:
--   `excercise_category_id`
--       `excercise_category` -> `id`
--
