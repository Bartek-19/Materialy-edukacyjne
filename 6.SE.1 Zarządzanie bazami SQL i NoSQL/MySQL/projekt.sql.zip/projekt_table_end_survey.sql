
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `end_survey`
--
-- Creation: Mar 12, 2025 at 03:54 PM
--

DROP TABLE IF EXISTS `end_survey`;
CREATE TABLE IF NOT EXISTS `end_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `users_training_plan_id` int(11) NOT NULL,
  `was_tracking_sleep` binary(1) NOT NULL,
  `amount_of_sleep` int(11) DEFAULT NULL,
  `was_tracking_nutrition` binary(1) NOT NULL,
  `personal_evaluation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`user_id`,`users_training_plan_id`),
  KEY `fk_end_survey_users_training_plans1_idx` (`user_id`,`users_training_plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `end_survey`:
--   `user_id`
--       `users_training_plans` -> `user_id`
--   `users_training_plan_id`
--       `users_training_plans` -> `plan_id`
--
