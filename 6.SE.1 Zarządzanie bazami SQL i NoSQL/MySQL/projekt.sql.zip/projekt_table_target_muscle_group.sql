
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `target_muscle_group`
--
-- Creation: Mar 12, 2025 at 03:56 PM
-- Ostatnia aktualizacja: Mar 12, 2025 at 04:09 PM
--

DROP TABLE IF EXISTS `target_muscle_group`;
CREATE TABLE IF NOT EXISTS `target_muscle_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- RELACJE DLA TABELI `target_muscle_group`:
--

--
-- Dumping data for table `target_muscle_group`
--

INSERT DELAYED IGNORE INTO `target_muscle_group` (`id`, `name`) VALUES
(1, 'Biceps'),
(2, 'Triceps'),
(3, 'Shoulders'),
(4, 'Upper chest'),
(5, 'Forearms'),
(6, 'Neck'),
(7, 'Upper back'),
(8, 'Lower chest'),
(9, 'Lats'),
(10, 'Lower back'),
(11, 'Glutes'),
(12, 'Hip flexors'),
(13, 'Abdominals'),
(14, 'Hamstrings'),
(15, 'Quadriceps'),
(16, 'Calves');
