import React, { useState } from 'react';
import { register } from '../api/authApi';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const [formData, setFormData] = useState({
    login: '',
    haslo: '',
    nazwa: '',
    opis: '',
    email: '',
    adres: {
      kodPocztowy: '',
      miejscowosc: '',
      ulica: '',
      numer: ''
    }
  });

  const navigate = useNavigate();

  const handleChange = e => {
    const { name, value } = e.target;

    if (name.startsWith('adres.')) {
      const key = name.split('.')[1];
      setFormData(prev => ({
        ...prev,
        adres: {
          ...prev.adres,
          [key]: key === 'numer' ? parseInt(value) : value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await register(formData);
      alert('Rejestracja zakończona sukcesem!');
      navigate('/login');
    } catch (err) {
      alert('Błąd podczas rejestracji: ' + (err.response?.data?.message || 'Spróbuj ponownie.'));
    }
  };

  return (
    <div>
      <h1>Rejestracja Pracodawcy</h1>
      <form onSubmit={handleSubmit}>
        <input name="nazwa" placeholder="Nazwa firmy" onChange={handleChange} required />
        <textarea name="opis" placeholder="Opis firmy" onChange={handleChange} required />
        <input name="email" type="email" placeholder="Email" onChange={handleChange} required />
        <input name="login" placeholder="Login" onChange={handleChange} required />
        <input name="haslo" type="password" placeholder="Hasło" onChange={handleChange} required />

        <h3>Adres firmy</h3>
        <input name="adres.kodPocztowy" placeholder="Kod pocztowy" onChange={handleChange} required />
        <input name="adres.miejscowosc" placeholder="Miejscowość" onChange={handleChange} required />
        <input name="adres.ulica" placeholder="Ulica" onChange={handleChange} required />
        <input name="adres.numer" type="number" placeholder="Numer" onChange={handleChange} required />

        <button type="submit">Zarejestruj się</button>
      </form>
    </div>
  );
};

export default Register;
