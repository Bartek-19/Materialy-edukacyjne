import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { fetchEmployerById, fetchEmployerJobs } from '../api/employerApi';

const EmployerDetail = () => {
  const { id } = useParams();
  const [employer, setEmployer] = useState(null);
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    fetchEmployerById(id).then(res => setEmployer(res.data));
    fetchEmployerJobs(id).then(res => setJobs(res.data));
  }, [id]);

  if (!employer) return <p>Ładowanie...</p>;

  return (
    <div>
      <h1>{employer.nazwa}</h1>
      <p>{employer.opis}</p>
      <p>{employer.adres}</p>
      <h3>Oferty pracy</h3>
      {jobs.map(job => (
        <p key={job.id}><Link to={`/job/${job.id}`}>{job.nazwa}</Link></p>
      ))}
    </div>
  );
};

export default EmployerDetail;