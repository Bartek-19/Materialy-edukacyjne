import React, { useState } from 'react';
import { login } from '../api/authApi';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [loginData, setLoginData] = useState({ login: '', haslo: '' });
  const navigate = useNavigate();

  const handleChange = e => {
    const { name, value } = e.target;
    setLoginData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const res = await login(loginData);
    //localStorage.setItem('token', res.data.token);
    navigate('/panel');
  };

  return (
    <div>
      <h1>Logowanie</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" name="login" value={loginData.login} onChange={handleChange} placeholder="Login" required />
        <input type="password" name="haslo" value={loginData.haslo} onChange={handleChange} placeholder="Hasło" required />
        <button type="submit">Zaloguj się</button>
      </form>
      <p><a href="/register">Zarejestruj się</a></p>
    </div>
  );
};

export default Login;