import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { fetchJobById } from '../api/jobApi';

const JobDetail = () => {
  const { id } = useParams();
  const [job, setJob] = useState(null);

  useEffect(() => {
    fetchJobById(id).then(res => setJob(res.data));
  }, [id]);

  if (!job) return <p>Ładowanie...</p>;

  return (
    <div>
      <h1>{job.nazwa}</h1>
      <p>{job.opis}</p>
      <p>Wynagrodzenie: {job.wynagrodzenie} - {job.wynagrodzenieGorne}</p>
      <p>Doświadczenie: {job.doswiadczenie}</p>
      <h3>Wytyczne</h3>
      {job.wytyczne.map(w => (
        <p key={w.id}><strong>{w.kategoria}:</strong> {w.opis}</p>
      ))}
      <p>
        <Link to={`/employer/${job.pracodawcaId}`}>Zobacz profil pracodawcy</Link>
      </p>
      <a href={`mailto:${job.email}`}>Kontakt</a>
    </div>
  );
};

export default JobDetail;