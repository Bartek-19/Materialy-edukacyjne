import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchMyProfile, updateProfile, fetchMyJobs, deleteJob } from '../api/employerApi';

const EmployerPanel = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const [employer, setEmployer] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({});

  useEffect(() => {
    if (!token) {
      navigate('/login');
      return;
    }

    const loadData = async () => {
      const res = await fetchMyProfile();
      setEmployer(res.data);
      setFormData(res.data);
      const jobsRes = await fetchMyJobs();
      setJobs(jobsRes.data);
    };

    loadData();
  }, [token, navigate]);

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleUpdate = async e => {
    e.preventDefault();
    await updateProfile(formData, token);
    setEditMode(false);
    setEmployer(formData);
  };

  const handleDeleteJob = async jobId => {
    if (window.confirm('Czy na pewno chcesz usunąć to ogłoszenie?')) {
      await deleteJob(jobId, token);
      setJobs(prev => prev.filter(job => job.id !== jobId));
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  if (!employer) return <p>Ładowanie danych...</p>;

  return (
    <div>
      <h1>Panel Pracodawcy</h1>
      <button onClick={logout}>Wyloguj się</button>

      <h2>Moje dane</h2>
      {editMode ? (
        <form onSubmit={handleUpdate}>
          <input name="nazwa" value={formData.nazwa} onChange={handleChange} placeholder="Nazwa firmy" required />
          <textarea name="opis" value={formData.opis} onChange={handleChange} placeholder="Opis firmy" required />
          <input name="email" type="email" value={formData.email} onChange={handleChange} placeholder="Email" required />
          <button type="submit">Zapisz</button>
          <button type="button" onClick={() => setEditMode(false)}>Anuluj</button>
        </form>
      ) : (
        <div>
          <p><strong>Nazwa:</strong> {employer.nazwa}</p>
          <p><strong>Opis:</strong> {employer.opis}</p>
          <p><strong>Email:</strong> {employer.email}</p>
          <button onClick={() => setEditMode(true)}>Edytuj dane</button>
        </div>
      )}

      <h2>Moje ogłoszenia</h2>
      <button onClick={() => navigate('/add-job')}>Dodaj nowe ogłoszenie</button>
      {jobs.length === 0 ? (
        <p>Brak ogłoszeń.</p>
      ) : (
        jobs.map(job => (
          <div key={job.id}>
            <h3>{job.nazwa}</h3>
            <p>{job.opis}</p>
            <p>Wynagrodzenie: {job.wynagrodzenie} - {job.wynagrodzenieGorne}</p>
            <button onClick={() => navigate(`/edit-job/${job.id}`)}>Edytuj</button>
            <button onClick={() => handleDeleteJob(job.id)}>Usuń</button>
          </div>
        ))
      )}
    </div>
  );
};

export default EmployerPanel;
