import React, { useEffect, useState } from 'react';
import { fetchJobs } from '../api/jobApi';
import { Link } from 'react-router-dom';

const JobList = () => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    fetchJobs().then(res => setJobs(res.data));
  }, []);

  return (
    <div>
      <h1>Oferty pracy</h1>
      {jobs.map(job => (
        <div key={job.id}>
          <Link to={`/job/${job.id}`}>
            <h3>{job.nazwa}</h3>
            <p>Pracodawca: {job.pracodawcaNazwa}</p>
          </Link>
        </div>
      ))}
    </div>
  );
};

export default JobList;