import React, { useState } from 'react';
import { createJob } from '../api/jobApi';
import { useNavigate } from 'react-router-dom';

const AddJob = () => {
  const [formData, setFormData] = useState({ nazwa: '', opis: '', wynagrodzenie: 0 });
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    await createJob(formData);
    navigate('/panel');
  };

  return (
    <div>
      <h1>Dodaj ogłoszenie</h1>
      <form onSubmit={handleSubmit}>
        <input name="nazwa" placeholder="Nazwa stanowiska" onChange={handleChange} required />
        <textarea name="opis" placeholder="Opis" onChange={handleChange} required />
        <input name="wynagrodzenie" type="number" onChange={handleChange} required />
        <button type="submit">Dodaj</button>
      </form>
    </div>
  );
};

export default AddJob;