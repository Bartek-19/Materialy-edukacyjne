import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import JobList from './pages/JobList';
import JobDetail from './pages/JobDetail';
import EmployerDetail from './pages/EmployerDetail';
import EmployerPanel from './pages/EmployerPanel';
import Login from './pages/Login';
import Register from './pages/Register';
import AddJob from './pages/AddJob';

function App() {
  return (
    <Router>
      <header>
        <nav>
          <Link to="/">Strona główna</Link> |{" "}
          <Link to="/login">Mój profil</Link>
        </nav>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<JobList />} />
          <Route path="/job/:id" element={<JobDetail />} />
          <Route path="/employer/:id" element={<EmployerDetail />} />
          <Route path="/panel" element={<EmployerPanel />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/add-job" element={<AddJob />} />
        </Routes>
      </main>
    </Router>
  );
}

export default App;
