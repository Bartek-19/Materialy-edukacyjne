import { Link } from 'react-router-dom';

const Header = ({ isLoggedIn, onLogout }) => (
  <header>
    <nav>
      <Link to="/">Strona główna</Link>
      {isLoggedIn ? (
        <>
          <Link to="/panel">Mój profil</Link>
          <button onClick={onLogout}>Wyloguj</button>
        </>
      ) : (
        <Link to="/login">Zaloguj się</Link>
      )}
    </nav>
  </header>
);

export default Header;
