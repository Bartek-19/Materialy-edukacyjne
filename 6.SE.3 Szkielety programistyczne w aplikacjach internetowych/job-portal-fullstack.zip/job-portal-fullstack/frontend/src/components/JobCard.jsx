import { Link } from 'react-router-dom';

const JobCard = ({ job }) => (
  <div className="job-card">
    <h3><Link to={`/job/${job.id}`}>{job.nazwa}</Link></h3>
    <p>{job.opis}</p>
    <p>Wynagrodzenie: {job.wynagrodzenie} - {job.wynagrodzenieGorne}</p>
    <p>Pracodawca: <Link to={`/employer/${job.pracodawca.id}`}>{job.pracodawca.nazwa}</Link></p>
  </div>
);

export default JobCard;
