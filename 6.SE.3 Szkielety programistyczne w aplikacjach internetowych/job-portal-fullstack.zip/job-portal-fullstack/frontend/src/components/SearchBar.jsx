import { useState } from 'react';

const SearchBar = ({ onSearch }) => {
  const [query, setQuery] = useState('');
  const [min, setMin] = useState('');
  const [max, setMax] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch({ query, min, max });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="Szukaj..." value={query} onChange={(e) => setQuery(e.target.value)} />
      <input type="number" placeholder="Min płaca" value={min} onChange={(e) => setMin(e.target.value)} />
      <input type="number" placeholder="Max płaca" value={max} onChange={(e) => setMax(e.target.value)} />
      <button type="submit">Szukaj</button>
    </form>
  );
};

export default SearchBar;
