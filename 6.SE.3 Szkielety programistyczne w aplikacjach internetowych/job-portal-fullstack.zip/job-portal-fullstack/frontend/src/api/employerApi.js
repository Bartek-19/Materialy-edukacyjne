import axios from 'axios';

const API_BASE = 'http://localhost:8080/api/employer';

const token = localStorage.getItem('token');
if (token) {
  axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
}

export const fetchEmployerById = (id) => {
  return axios.get(`${API_BASE}/${id}`);
};

export const updateEmployer = (id, data) => {
  return axios.put(`${API_BASE}/${id}`, data);
};

export const fetchEmployerJobs = (id) => {
  return axios.get(`${API_BASE}/${id}/jobs`);
};

export const fetchMyProfile = () => {
  return axios.get(`${API_BASE}/me`);
};

export const fetchMyJobs = () => {
    return axios.get(`${API_BASE}/me/jobs`);
};

export const updateProfile = (data) => {
    return axios.put(`${API_BASE}/me`, data);
};

export const deleteJob = (jobId) => {
    return axios.delete(`http://localhost:8080/api/jobs/${jobId}`);
};