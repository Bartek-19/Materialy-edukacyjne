import axios from 'axios';

const API_BASE = 'http://localhost:8080/api/auth';

const token = localStorage.getItem('token');
if (token) {
  axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
}

export const login = (credentials) => {
  return axios.post(`${API_BASE}/login`, credentials)
    .then(res => {
      localStorage.setItem('token', res.data.token)
    });
};

export const logout = () => {
  return axios.post(`${API_BASE}/logout`);
};

export const register = (data) => {
  return axios.post(`${API_BASE}/register`, data);
};
