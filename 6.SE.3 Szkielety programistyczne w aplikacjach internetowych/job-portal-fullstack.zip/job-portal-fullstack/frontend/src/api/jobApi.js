import axios from 'axios';

const API_BASE = 'http://localhost:8080/api/jobs';
const token = localStorage.getItem('token');
if (token) {
  axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
}

export const fetchJobs = (filters = {}) => {
  return axios.get(API_BASE, { params: filters });
};

export const fetchJobById = (id) => {
  return axios.get(`${API_BASE}/${id}`);
};

export const createJob = (jobData) => {
  return axios.post(API_BASE, jobData);
};

export const updateJob = (id, jobData) => {
  return axios.put(`${API_BASE}/${id}`, jobData);
};

export const deleteJob = (id) => {
  return axios.delete(`${API_BASE}/${id}`);
};
