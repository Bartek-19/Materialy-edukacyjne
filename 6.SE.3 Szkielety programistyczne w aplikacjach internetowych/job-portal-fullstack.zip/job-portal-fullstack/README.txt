Portal z ogłoszeniami o pracę
Autor: Bartosz Klimiuk

Funkcjonalności:
1. Rejestracja, logowanie się do serwisu jako pracodawca
2. Dodawanie, edytowanie i usuwanie ogłoszeń jako pracodawca
3. Edytowanie danych profilu jako pracodawca
4. Przeglądanie ofert pracy jako dowolny użytkownik
5. Filtrowanie ofert pracy jako dowolny użytkownik
6. Podgląd profilu pracodawcy oraz jego ogłoszeń jako dowolny użytkownik
7. Podgląd szczegółów ogłoszeń jako dowolny użytkownik
8. Autoryzacja wymagana przy funkcjonalnościach pracodawcy
9. Możliwość kontaktu z pracodawcą poprzez wiadomość e-mail jako dowolny użytkownik

Uruchomienie serwisu:
1. Baza danych - uruchomienie serwera bazy danych MySQL poprzez serwer Apache w programie XAMPP
	1a. Wykonanie polecenia SQL: CREATE DATABASE projektzaliczeniowy CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
2. Backend - uruchomienie aplikacji poprzez IDE InteliJ
	2a. Zaktualizowanie zależności z pliku pom.xml
	2b. Uruchomienie JobPortalApplication.java
	LUB poprzez CMD (
		backend> mvn clean install
		backend> mvn spring-boot:run
	)
3. Frontend
	3a. Doinstalowanie potrzebnych modułów poprzez CMD (
		frontend> npm install
		frontend> npm install axios react-router-dom
	)
	3b. Uruchomienie frontendu - frontend> npm start

Wykorzystywane wersje oprogramowania i frameworków:
XAMPP - 3.3.0
SpringBoot - 3.2.5
Java - 21
React - 19.1.0