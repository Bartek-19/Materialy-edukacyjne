package com.example.jobportal.controller;

import com.example.jobportal.model.Adres;
import com.example.jobportal.model.Ogloszenie;
import com.example.jobportal.model.Pracodawca;
import com.example.jobportal.model.Wytyczne;
import com.example.jobportal.repository.OgloszenieRepository;
import com.example.jobportal.repository.PracodawcaRepository;
import com.example.jobportal.repository.WytyczneRepository;
import com.example.jobportal.service.EmployerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/jobs")
public class JobAdController {

    private final OgloszenieRepository ogloszenieRepository;
    private final WytyczneRepository wytyczneRepository;

    @Autowired
    public JobAdController(OgloszenieRepository ogloszenieRepository,
                           WytyczneRepository wytyczneRepository,
                           PracodawcaRepository pracodawcaRepository) {
        this.ogloszenieRepository = ogloszenieRepository;
        this.wytyczneRepository = wytyczneRepository;
    }

    @PostMapping
    public ResponseEntity<Ogloszenie> registerEmployer(@RequestBody Ogloszenie ogloszenie) {
        Ogloszenie newOgloszenie = new Ogloszenie(
                null,
                ogloszenie.getNazwa(),
                ogloszenie.getOpis(),
                ogloszenie.getWynagrodzenie(),
                ogloszenie.getWynagrodzenieGorne(),
                ogloszenie.getPracodawca(),
                ogloszenie.getDoswiadczenie()
        );

        return ResponseEntity.ok(ogloszenieRepository.save(newOgloszenie));
    }

    @GetMapping
    public List<Ogloszenie> getAllJobAds() {
        return ogloszenieRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getJobAdById(@PathVariable Integer id) {
        Optional<Ogloszenie> ogloszenie = ogloszenieRepository.findById(id);
        if (ogloszenie.isEmpty()) return ResponseEntity.notFound().build();

        List<Wytyczne> wytyczne = wytyczneRepository.findByOgloszenieId(id);
        Map<String, List<Wytyczne>> wytyczneByKategoria = new HashMap<>();

        for (Wytyczne w : wytyczne) {
            wytyczneByKategoria.computeIfAbsent(w.getKategoria(), k -> new ArrayList<>()).add(w);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("ogloszenie", ogloszenie.get());
        response.put("wytyczne", wytyczneByKategoria);

        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteJobAd(@PathVariable Integer id) {
        if (!ogloszenieRepository.existsById(id)) return ResponseEntity.notFound().build();
        ogloszenieRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
