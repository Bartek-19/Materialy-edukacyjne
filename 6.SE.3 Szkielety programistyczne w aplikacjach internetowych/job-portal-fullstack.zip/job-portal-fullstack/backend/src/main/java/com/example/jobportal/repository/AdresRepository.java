package com.example.jobportal.repository;

import com.example.jobportal.model.Adres;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdresRepository extends JpaRepository<Adres, Integer> {
}
