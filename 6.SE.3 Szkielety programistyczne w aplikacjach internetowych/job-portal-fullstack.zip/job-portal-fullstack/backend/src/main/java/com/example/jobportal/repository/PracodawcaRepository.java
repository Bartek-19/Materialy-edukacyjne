package com.example.jobportal.repository;

import com.example.jobportal.model.Pracodawca;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PracodawcaRepository extends JpaRepository<Pracodawca, Integer> {
    boolean existsByEmail(String email);
    boolean existsByLogin(String login);
    Optional<Pracodawca> findByLogin(String login);
}
