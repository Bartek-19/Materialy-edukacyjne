package com.example.jobportal.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Adres")
public class Adres {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 6)
    private String kodPocztowy;

    @Column(nullable = false, length = 20)
    private String miejscowosc;

    @Column(nullable = false, length = 20)
    private String ulica;

    @Column(nullable = false)
    private Short numer;

    public Adres(Integer id, String kodPocztowy, String miejscowosc, String ulica, Short numer) {
        this.id = id;
        this.kodPocztowy = kodPocztowy;
        this.miejscowosc = miejscowosc;
        this.ulica = ulica;
        this.numer = numer;
    }

    // Hibernate requires default constructor
    protected Adres() {
        this.id = null;
        this.kodPocztowy = null;
        this.miejscowosc = null;
        this.ulica = null;
        this.numer = null;
    }

    public Integer getId() {
        return id;
    }

    public String getKodPocztowy() {
        return kodPocztowy;
    }

    public String getMiejscowosc() {
        return miejscowosc;
    }

    public String getUlica() {
        return ulica;
    }

    public Short getNumer() {
        return numer;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setKodPocztowy(String kodPocztowy) {
        this.kodPocztowy = kodPocztowy;
    }

    public void setMiejscowosc(String miejscowosc) {
        this.miejscowosc = miejscowosc;
    }

    public void setUlica(String ulica) {
        this.ulica = ulica;
    }

    public void setNumer(Short numer) {
        this.numer = numer;
    }
}
