package com.example.jobportal.controller;

import com.example.jobportal.model.Adres;
import com.example.jobportal.model.Pracodawca;
import com.example.jobportal.repository.AdresRepository;
import com.example.jobportal.repository.PracodawcaRepository;
import com.example.jobportal.service.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final PracodawcaRepository pracodawcaRepository;
    private final AdresRepository adresRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthController(PracodawcaRepository pracodawcaRepository,
                          AdresRepository adresRepository,
                          PasswordEncoder passwordEncoder,
                          JwtUtil jwtUtil) {
        this.pracodawcaRepository = pracodawcaRepository;
        this.adresRepository = adresRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/register")
    public ResponseEntity<Pracodawca> registerEmployer(@RequestBody Pracodawca pracodawca) {
        if (pracodawcaRepository.existsByEmail(pracodawca.getEmail()) ||
                pracodawcaRepository.existsByLogin(pracodawca.getLogin())) {
            return ResponseEntity.badRequest().build();
        }
        Adres savedAdres = adresRepository.save(pracodawca.getAdres());
        Pracodawca newEmployer = new Pracodawca(
                null,
                pracodawca.getNazwa(),
                pracodawca.getOpis(),
                pracodawca.getEmail(),
                passwordEncoder.encode(pracodawca.getHaslo()),
                pracodawca.getLogin(),
                savedAdres
        );
        return ResponseEntity.ok(pracodawcaRepository.save(newEmployer));
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@RequestBody Pracodawca loginData) {
        return pracodawcaRepository.findByLogin(loginData.getLogin())
                .filter(user -> passwordEncoder.matches(loginData.getHaslo(), user.getHaslo()))
                .map(user -> {
                    String token = jwtUtil.generateToken(user);
                    return ResponseEntity.ok(Map.of("token", token));
                })
                .orElseGet(() -> ResponseEntity.status(401).build());
    }
}