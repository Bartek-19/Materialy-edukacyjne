package com.example.jobportal.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Wytyczne")
public class Wytyczne {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String kategoria; // Enum jako String

    @Column(nullable = false, length = 30)
    private String opis;

    @ManyToOne
    @JoinColumn(name = "ogloszenie_id", nullable = false)
    private Ogloszenie ogloszenie;

    public Wytyczne(Integer id, String kategoria, String opis, Ogloszenie ogloszenie) {
        this.id = id;
        this.kategoria = kategoria;
        this.opis = opis;
        this.ogloszenie = ogloszenie;
    }

    protected Wytyczne() {
        this.id = null;
        this.kategoria = null;
        this.opis = null;
        this.ogloszenie = null;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getKategoria() {
        return kategoria;
    }

    public void setKategoria(String kategoria) {
        this.kategoria = kategoria;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public Ogloszenie getOgloszenie() {
        return ogloszenie;
    }

    public void setOgloszenie(Ogloszenie ogloszenie) {
        this.ogloszenie = ogloszenie;
    }
}
