package com.example.jobportal.repository;

import com.example.jobportal.model.Wytyczne;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WytyczneRepository extends JpaRepository<Wytyczne, Integer> {
    List<Wytyczne> findByOgloszenieId(Integer ogloszenieId);
}
