package com.example.jobportal.service;

import com.example.jobportal.model.Ogloszenie;
import com.example.jobportal.repository.OgloszenieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobService {

    private final OgloszenieRepository ogloszenieRepository;

    @Autowired
    public JobService(OgloszenieRepository ogloszenieRepository) {
        this.ogloszenieRepository = ogloszenieRepository;
    }

    public List<Ogloszenie> getAllJobs() {
        return ogloszenieRepository.findAll();
    }

    public List<Ogloszenie> getJobsByPracodawcaId(Integer pracodawcaId) {
        return ogloszenieRepository.findByPracodawcaId(pracodawcaId);
    }

    public Ogloszenie getJobById(Integer id) {
        Optional<Ogloszenie> optional = ogloszenieRepository.findById(id);
        return optional.orElseThrow(() -> new RuntimeException("Ogłoszenie o ID " + id + " nie istnieje."));
    }

    public Ogloszenie createJob(Ogloszenie ogloszenie) {
        return ogloszenieRepository.save(ogloszenie);
    }

    public Ogloszenie updateJob(Integer id, Ogloszenie updated) {
        Ogloszenie existing = getJobById(id);

        existing.setNazwa(updated.getNazwa());
        existing.setOpis(updated.getOpis());
        existing.setWynagrodzenie(updated.getWynagrodzenie());
        existing.setWynagrodzenieGorne(updated.getWynagrodzenieGorne());
        existing.setDoswiadczenie(updated.getDoswiadczenie());

        return ogloszenieRepository.save(existing);
    }

    public void deleteJob(Integer id) {
        if (!ogloszenieRepository.existsById(id)) {
            throw new RuntimeException("Nie znaleziono ogłoszenia o ID " + id);
        }
        ogloszenieRepository.deleteById(id);
    }
}
