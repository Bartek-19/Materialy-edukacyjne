package com.example.jobportal.repository;

import com.example.jobportal.model.Doswiadczenie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DoswiadczenieRepository extends JpaRepository<Doswiadczenie, Short> {
}
