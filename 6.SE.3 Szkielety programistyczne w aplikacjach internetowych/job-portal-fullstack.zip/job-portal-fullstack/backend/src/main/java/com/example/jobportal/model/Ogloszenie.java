package com.example.jobportal.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Ogloszenie")
public class Ogloszenie {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 30)
    private String nazwa;

    @Column(nullable = false, length = 200)
    private String opis;

    @Column(nullable = false)
    private Integer wynagrodzenie;

    @Column
    private Integer wynagrodzenieGorne;

    @ManyToOne
    @JoinColumn(name = "pracodawca_id", nullable = false)
    private Pracodawca pracodawca;

    @ManyToOne
    @JoinColumn(name = "doswiadczenie_id")
    private Doswiadczenie doswiadczenie;

    public Ogloszenie(Integer id,
                      String nazwa,
                      String opis,
                      Integer wynagrodzenie,
                      Integer wynagrodzenieGorne,
                      Pracodawca pracodawca,
                      Doswiadczenie doswiadczenie) {
        this.id = id;
        this.nazwa = nazwa;
        this.opis = opis;
        this.wynagrodzenie = wynagrodzenie;
        this.wynagrodzenieGorne = wynagrodzenieGorne;
        this.pracodawca = pracodawca;
        this.doswiadczenie = doswiadczenie;
    }

    protected Ogloszenie() {
        this.id = null;
        this.nazwa = null;
        this.opis = null;
        this.wynagrodzenie = null;
        this.wynagrodzenieGorne = null;
        this.pracodawca = null;
        this.doswiadczenie = null;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public Integer getWynagrodzenie() {
        return wynagrodzenie;
    }

    public void setWynagrodzenie(Integer wynagrodzenie) {
        this.wynagrodzenie = wynagrodzenie;
    }

    public Integer getWynagrodzenieGorne() {
        return wynagrodzenieGorne;
    }

    public void setWynagrodzenieGorne(Integer wynagrodzenieGorne) {
        this.wynagrodzenieGorne = wynagrodzenieGorne;
    }

    public Pracodawca getPracodawca() {
        return pracodawca;
    }

    public void setPracodawca(Pracodawca pracodawca) {
        this.pracodawca = pracodawca;
    }

    public Doswiadczenie getDoswiadczenie() {
        return doswiadczenie;
    }

    public void setDoswiadczenie(Doswiadczenie doswiadczenie) {
        this.doswiadczenie = doswiadczenie;
    }
}
