package com.example.jobportal.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Doswiadczenie")
public class Doswiadczenie {
    @Id
    private Short id;

    @Column(unique = true, nullable = false, length = 10)
    private String nazwa;

    public Doswiadczenie(Short id, String nazwa) {
        this.id = id;
        this.nazwa = nazwa;
    }

    protected Doswiadczenie() {
        this.id = null;
        this.nazwa = null;
    }

    public Short getId() {
        return id;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setId(Short id) {
        this.id = id;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }
}
