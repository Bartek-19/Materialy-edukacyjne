package com.example.jobportal.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Pracodawca")
public class Pracodawca {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(unique = true, nullable = false, length = 30)
    private String nazwa;

    @Column(nullable = false, length = 100)
    private String opis;

    @Column(unique = true, nullable = false, length = 20)
    private String email;

    @Column(nullable = false, length = 255)
    private String haslo;

    @Column(unique = true, nullable = false, length = 20)
    private String login;

    @ManyToOne
    @JoinColumn(name = "adres_id")
    private Adres adres;

    public Pracodawca(Integer id,
                      String nazwa,
                      String opis,
                      String email,
                      String haslo,
                      String login,
                      Adres adres) {
        this.id = id;
        this.nazwa = nazwa;
        this.opis = opis;
        this.email = email;
        this.haslo = haslo;
        this.login = login;
        this.adres = adres;
    }

    protected Pracodawca() {
        this.id = null;
        this.nazwa = null;
        this.opis = null;
        this.email = null;
        this.haslo = null;
        this.login = null;
        this.adres = null;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getHaslo() {
        return haslo;
    }

    public void setHaslo(String haslo) {
        this.haslo = haslo;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Adres getAdres() {
        return adres;
    }

    public void setAdres(Adres adres) {
        this.adres = adres;
    }
}
