package com.example.jobportal.service;

import com.example.jobportal.model.Pracodawca;
import com.example.jobportal.model.Adres;
import com.example.jobportal.repository.PracodawcaRepository;
import com.example.jobportal.repository.AdresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EmployerService {

    private final PracodawcaRepository pracodawcaRepository;
    private final AdresRepository adresRepository;

    @Autowired
    public EmployerService(PracodawcaRepository pracodawcaRepository,
                           AdresRepository adresRepository) {
        this.pracodawcaRepository = pracodawcaRepository;
        this.adresRepository = adresRepository;
    }

    public Optional<Pracodawca> findById(Integer id) {
        return pracodawcaRepository.findById(id);
    }

    public Pracodawca save(Pracodawca pracodawca) {
        Adres adres = adresRepository.save(pracodawca.getAdres());
        pracodawca.setAdres(adres);
        return pracodawcaRepository.save(pracodawca);
    }

    public Pracodawca updateEmployer(Integer id, Pracodawca updated) {
        Pracodawca existing = pracodawcaRepository.findById(id).orElseThrow();
        existing.setNazwa(updated.getNazwa());
        existing.setOpis(updated.getOpis());
        existing.setAdres(updated.getAdres());
        return pracodawcaRepository.save(existing);
    }
}
