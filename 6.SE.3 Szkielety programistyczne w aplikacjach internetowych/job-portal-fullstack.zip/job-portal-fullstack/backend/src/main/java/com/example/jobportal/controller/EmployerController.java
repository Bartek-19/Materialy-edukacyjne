package com.example.jobportal.controller;

import com.example.jobportal.model.Ogloszenie;
import com.example.jobportal.model.Pracodawca;
import com.example.jobportal.model.Adres;
import com.example.jobportal.repository.PracodawcaRepository;
import com.example.jobportal.repository.AdresRepository;
import com.example.jobportal.service.EmployerService;
import com.example.jobportal.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/employer")
public class EmployerController {

    private final PracodawcaRepository pracodawcaRepository;
    private final AdresRepository adresRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmployerService employerService;
    private final JobService jobService;

    @Autowired
    public EmployerController(PracodawcaRepository pracodawcaRepository,
                              AdresRepository adresRepository,
                              PasswordEncoder passwordEncoder,
                              EmployerService employerService,
                              JobService jobService) {
        this.pracodawcaRepository = pracodawcaRepository;
        this.adresRepository = adresRepository;
        this.passwordEncoder = passwordEncoder;
        this.employerService = employerService;
        this.jobService = jobService;
    }

    @GetMapping
    public List<Pracodawca> getAllEmployers() {
        return pracodawcaRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pracodawca> getEmployerById(@PathVariable Integer id) {
        Optional<Pracodawca> pracodawca = pracodawcaRepository.findById(id);
        return pracodawca.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/register")
    public ResponseEntity<Pracodawca> registerEmployer(@RequestBody Pracodawca pracodawca) {
        if (pracodawcaRepository.existsByEmail(pracodawca.getEmail()) ||
                pracodawcaRepository.existsByLogin(pracodawca.getLogin())) {
            return ResponseEntity.badRequest().build();
        }

        Adres adres = pracodawca.getAdres();
        Adres savedAdres = adresRepository.save(adres);

        Pracodawca newEmployer = new Pracodawca(
                null,
                pracodawca.getNazwa(),
                pracodawca.getOpis(),
                pracodawca.getEmail(),
                passwordEncoder.encode(pracodawca.getHaslo()),
                pracodawca.getLogin(),
                savedAdres
        );

        return ResponseEntity.ok(pracodawcaRepository.save(newEmployer));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pracodawca> updateEmployer(@PathVariable Integer id,
                                                     @RequestBody Pracodawca updatedData) {
        Optional<Pracodawca> existing = pracodawcaRepository.findById(id);
        if (existing.isEmpty()) return ResponseEntity.notFound().build();

        Pracodawca current = existing.get();

        Adres updatedAdres = updatedData.getAdres();
        Adres savedAdres = adresRepository.save(updatedAdres);

        Pracodawca updated = new Pracodawca(
                current.getId(),
                updatedData.getNazwa(),
                updatedData.getOpis(),
                updatedData.getEmail(),
                current.getHaslo(),
                current.getLogin(),
                savedAdres
        );

        return ResponseEntity.ok(pracodawcaRepository.save(updated));
    }

    @GetMapping("/me")
    public ResponseEntity<Pracodawca> getMyProfile(@AuthenticationPrincipal Pracodawca me) {
        return ResponseEntity.ok(me);
    }

    @GetMapping("/me/jobs")
    public ResponseEntity<List<Ogloszenie>> getMyJobs(@AuthenticationPrincipal Pracodawca me) {
        return ResponseEntity.ok(jobService.getJobsByPracodawcaId(me.getId()));
    }

    @PutMapping("/me")
    public ResponseEntity<Pracodawca> updateMyProfile(@AuthenticationPrincipal Pracodawca me, @RequestBody Pracodawca updated) {
        Pracodawca result = employerService.updateEmployer(me.getId(), updated);
        return ResponseEntity.ok(result);
    }

    @DeleteMapping("/jobs/{jobId}")
    public ResponseEntity<Void> deleteJob(@AuthenticationPrincipal Pracodawca me, @PathVariable Integer jobId) {
        Ogloszenie job = jobService.getJobById(jobId);
        if (!job.getPracodawca().getId().equals(me.getId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        jobService.deleteJob(jobId);
        return ResponseEntity.noContent().build();
    }
}
