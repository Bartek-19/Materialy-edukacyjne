package com.example.jobportal.repository;

import com.example.jobportal.model.Ogloszenie;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OgloszenieRepository extends JpaRepository<Ogloszenie, Integer> {
    List<Ogloszenie> findByPracodawcaId(Integer pracodawcaId);
}
