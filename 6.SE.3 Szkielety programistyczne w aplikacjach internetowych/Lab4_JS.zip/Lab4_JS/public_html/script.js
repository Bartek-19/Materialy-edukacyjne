function sumator(...liczby) {
    var S = 0;
    for(let l of liczby) {
        S += l;
    }
    console.log(`Suma liczb ${liczby} wynosi ${S}`);
}

sumator(1, 2, 3, 5);

const listaZadan = [
    { 
        id: 1,
        tekst: "Zrobienie zakupów",
        zrealizowano: true
    },
    {
        id: 2,
        tekst: "Przegląd techniczny samochodu",
        zrealizowano: false
    },
    {
        id: 3,
        tekst: "Wizyta u dentysty",
        zrealizowano: false
    }
];

function wyswietlListeZadan(listaZadan) {
    var stan;
    console.log("\nOryginalna lista zadań:");
    listaZadan.forEach( (war)=>{
            stan = (war.zrealizowano) ? "T" : "N";
            console.log(`${war.id}. ${war.tekst} - ${stan}`);
        }
    );
    
    listaTekstowa = listaZadan.map( (war) => `${war.id}. ${war.tekst} - ${(war.zrealizowano) ? "T" : "N"}` );
    console.log("\nLista zadań w formie tekstowej:");
    listaTekstowa.forEach( (x)=>console.log(x) );
    
    listaZrealizowanych = listaZadan.filter(war => war.zrealizowano === true);
    console.log("\nLista zadań wykonanych:");
    listaZrealizowanych.forEach( (x)=>console.log(`${x.id}. ${x.tekst} - ${(x.zrealizowano) ? "T" : "N"}`) );
}

wyswietlListeZadan(listaZadan);

const poniedzialek = [
    {
        nazwa: 'Przygotowania do zajęć z AI',
        czas: 180
    },
    {
        nazwa: 'Realizacja projektu z AI',
        czas: 120
    }
];

const wtorek = [
    {
        nazwa: 'Rozbudowa swojego bloga',
        czas: 240
    },
    {
        nazwa: 'Administrowanie serwisem szkoly',
        czas: 180
    },
    {
        nazwa: 'Sluchanie koncertu online',
        czas: 240
    }
];

const dni = { poniedzialek, wtorek };

const polaczonaTablica = Object.entries(dni).reduce((acc, [dzien, zadania]) => {
    return acc.concat(zadania.map(zadanie => ({ ...zadanie, dzien })));
}, [])
        .map((v) => v.czas /= 60)
        .filter((v) => v > 2)
        .map((v) => v *= 35)
        .reduce(function (acc, curr) {return [(+acc) + (+curr)];})
        .map((v) => v.toFixed(2))
        .reduce((acc, val) => val, null);
console.log(polaczonaTablica);


        



