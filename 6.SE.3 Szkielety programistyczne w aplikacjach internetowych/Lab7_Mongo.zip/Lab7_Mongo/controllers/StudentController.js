const app = express()

app.get("/", (req, res) => {
    res.send(`
    <h3 style="text-align:center">Baza danych studentów</h3>
    <h4 style="text-align:center">Kliknij <a href="/list"> tutaj</a>, aby uzyskać dostęp do bazy.</h4>`)
})

app.get("/list", (req, res) => {
    Student.find().then((docs) => {
        res.render("list", {
            list: docs
        })
    }).catch((err) => {
        console.log("Błąd pobierania danych" + err)
    })
})
    
app.get("/addOrEdit", (req, res) => {
        res.render("addOrEdit", {
            viewTitle: "Dodaj studenta"
        })
})
    
app.post("/", (req, res) => {
    if (req.body._id == "") {
        insert(req, res)
    } else {
        update(req, res)
    }
})
    
app.get("/:id", (req, res) => {
    Student.findById(req.params.id).then((doc) => {
        res.render("addOrEdit", {
            viewTitle: "Zaktualizuj dane studenta",
            student: doc
        })
    }).catch((err) => {
        console.log("Błąd podczas akutalizowania danych" + err)
    })
})
    
app.get("/delete/:id", (req, res) => {
    Student.findByIdAndDelete(req.params.id).then((doc) => {
        res.redirect("/list")
    }).catch((err) => {
        console.log("Błąd podczas usuwania: " + err)
    })
})

module.exports = app