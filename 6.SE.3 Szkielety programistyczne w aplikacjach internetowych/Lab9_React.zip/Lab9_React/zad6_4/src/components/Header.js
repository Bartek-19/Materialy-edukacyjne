const Header = ({ title }) => {
    return <h2>{title}</h2>
}

export default Header