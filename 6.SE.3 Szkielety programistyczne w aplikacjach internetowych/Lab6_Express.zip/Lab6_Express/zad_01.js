var express = require('express');
var app = express();
const port = 3000;

app.get('/', function(req, res){
   res.send("Prosty serwer oparty na szkielecie programistycznym Express!");
});

app.get('/about', function(req, res){
    res.send("Autor strony: Bartosz Klimiuk");
});

app.get('/name/:imie', function(req, res){
    //res.type('.html');
    res.send(`<h1>Cześć ${req.params.imie}</h1>`);
});

app.get('/name/:imie1/:imie2', function(req, res){
    res.send(`<h1>Cześć ${req.params.imie1} i ${req.params.imie2}</h1>`);
});

app.listen(port, () => {
    console.log(`Serwer działa na porcie ${port}`);
});