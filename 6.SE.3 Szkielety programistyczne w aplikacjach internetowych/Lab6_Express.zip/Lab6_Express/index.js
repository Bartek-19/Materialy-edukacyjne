const express = require('express')
const path = require('path')
const bodyParser = require('body-parser') //npm install body-parser
const app = express()
const PORT = 3000
const { check, validationResult } = require('express-validator') //npm install express-validator
const users = require('./users')
const sanitizeValue = value => {
    return value.toUpperCase().replace(/[^A-Z]/g, '');
}
const users = require("./users")
let metoda = (req, res, next) => { 
    console.log("Metoda: ",req.method) 
    let sciezka = "Ścieżka: "+ req.protocol + "://" + req.get('host') + req.originalUrl 
    console.log(sciezka) 
    res.send(sciezka)
    next() 
} 

app.use(bodyParser.urlencoded({ extended: true }))

app.get("/form", (req, res) => {
    res.sendFile(path.join(__dirname, "form.html"));
});

app.post("/form", [
    check('nazwisko')
        .isLength({ min: 3 , max: 25 })
        .withMessage("Nazwisko nie spełnia wymogów długości! (Od 3 do 25 znaków)")
        .trim()
        .stripLow()
        .customSanitizer(sanitizeValue),
    check('nazwisko')
        .isAlpha()
        .withMessage("Podano min. 1 zły znak!")
        .bail()
        .trim()
        .stripLow(),
    check('email')
        .isEmail()
        .withMessage("Wprowadzono niepoprawny adres e-mail!")
        .normalizeEmail()
        .bail()
        .trim()
        .stripLow(),
    check('wiek')
        .isNumeric({ min: 0, max: 110 })
        .withMessage("Wprowadzono zły format liczby/za dużą liczbę (110<)/za małą liczbę (<0)")
        .bail()
        .trim()
        .stripLow()
    
], (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
        return res.status(422).json({ errors: errors.array() })
    }
    const nazwisko = req.body.nazwisko
    const email = req.body.email
    const wiek = req.body.wiek
    res.send("Użytkownik: " + nazwisko + "<br>Email: " + email + "<br>Wiek: " + wiek)
})

app.get("/form1", (req, res) => {
    res.sendFile(path.join(__dirname, "form1.html"));
});

app.post("/result", (req, res) => {
    let username = req.body.username
    let password = req.body.password
    res.send("Użytkownik: " + username + "<br>Hasło: " + password)
})

app.post("/result1", (req, res) => {
    let imieINazwisko = req.body.imieINazwisko;
    let jezyki = req.body.jezyki || [];

    let result = `<h3>Imię i nazwisko: ${imieINazwisko}</h3>`;

    if (jezyki.length > 0) {
        result += "<h4>Zaznaczone języki:</h4><ul>";
        jezyki.forEach(jezyk => {
            result += `<li>${jezyk}</li>`;
        });
        result += "</ul>";
    } else {
        result += "<p>Nie zaznaczono żadnego języka.</p>";
    }

    res.send(result);
});

app.get('/api/users', (req,res) => { 
    res.json(users) 
});

app.get('/api/users/:id', (req, res) => { 
    const found = users.some(user => user.id === parseInt(req.params.id)) 
    if(found){ 
        res.json(users.filter(user => user.id === parseInt(req.params.id))) 
    } else { 
        res.status(400).json({msg: `Użytkownik o id ${req.params.id} nie został odnaleziony`})
    } 
});

app.post('/api/users', (req, res) => { 
    const newUser = { 
        id: users.length + 1, 
        name: req.body.name, 
        email: req.body.email, 
        status: "aktywny" 
    } 
    if(!newUser.name || !newUser.email){ 
        return res.status(400).json({msg: 'Wprowadź poprawne imię i nazwisko oraz email!'}) 
    } 
    users.push(newUser) 
    res.json(users) 
});

app.patch('/api/users/:id', (req, res) => { 
    const found = users.some(user => user.id === parseInt(req.params.id)) 
    if(found){ 
        const updUser = req.body 
        users.forEach(user => { 
            if(user.id === parseInt(req.params.id)) { 
                user.name = updUser.name ? updUser.name : user.name 
                user.email = updUser.email ? updUser.email :  user.email 
                res.json({msg: 'Dane użytkownika zaktualizowane', user}) 
            } 
        }) 
    } else { 
    res.status(400).json({msg: `Użytkownik o id ${req.params.id} nie istnieje!`}) 
    } 
});

app.listen(PORT, ()=> console.log(`Serwer działa na porcie ${PORT}`))
