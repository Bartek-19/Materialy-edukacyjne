const users = [ 
    { 
        id: 1, 
        name: "Jan Kowalski", 
        email: "jan.kowalski@gmail.com", 
        status: "aktywny" 
    }, 
    { 
        id: 2, 
        name: "Adam Nowak", 
        email: "adam.nowak@gmail.com", 
        status: "nieaktywny" 
    }, 
    { 
        id: 3, 
        name: "Andrzej Stach", 
        email: "andrzej.stach@gmail.com", 
        status: "aktywny" 
    }, 
] 

module.exports = users;